Page({
  data: {},
  onLoad() {
    setTimeout(() => {
      dd.navigateTo({ url: '/pages/page3/page3' })
    }, 2000)
  },
});
