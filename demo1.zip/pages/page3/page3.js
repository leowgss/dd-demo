Page({
  data: {},
  onLoad() {
    setTimeout(() => {
      dd.reLaunch({
        url: "/pages/index/index",
        success() {
          dd.showToast({
            type: "success",
            content: "登录已失效，正在重新登录",
            duration: 1000,
          }).catch(() => {});
        },
        fail() {
          dd.showToast({
            type: "fail",
            content: "登录已失效，请退出重进",
            duration: 3000,
          }).catch(() => {});
        },
      });
    }, 2000);
  },
});
